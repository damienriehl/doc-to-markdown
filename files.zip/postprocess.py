#!/usr/bin/env python3
"""
Markdown Post-Processor
========================
Cleans conversion artifacts from Pandoc/Marker output and injects
YAML front matter optimized for RAG retrieval.
"""

import re
from datetime import date


class PostProcessor:
    """Clean and enhance converted Markdown for RAG consumption."""

    def clean(self, text: str) -> str:
        """Remove common conversion artifacts from Markdown text."""
        # Remove stray backslash escapes before punctuation
        text = re.sub(r"\\([.,:;!?'\"\-\(\)\[\]])", r"\1", text)

        # Collapse multiple blank lines to double newline
        text = re.sub(r"\n{3,}", "\n\n", text)

        # Remove trailing whitespace on each line
        text = re.sub(r"[ \t]+$", "", text, flags=re.MULTILINE)

        # Fix broken Markdown links from Pandoc (spaces in URLs)
        text = re.sub(r"\]\(\s+", "](", text)
        text = re.sub(r"\s+\)", ")", text)

        # Remove Word-style smart quotes that survived as escape sequences
        text = text.replace("\u2018", "'").replace("\u2019", "'")
        text = text.replace("\u201c", '"').replace("\u201d", '"')

        # Remove Pandoc's {.unnumbered} and similar attributes on headings
        text = re.sub(r"\s*\{[^}]*\}\s*$", "", text, flags=re.MULTILINE)

        # Normalize heading spacing: ensure blank line before headings
        text = re.sub(r"([^\n])\n(#{1,6}\s)", r"\1\n\n\2", text)

        # Strip leading/trailing whitespace from the whole document
        text = text.strip() + "\n"

        return text

    def normalize_headings(self, text: str) -> str:
        """Ensure heading hierarchy starts at H2 (H1 reserved for title)."""
        lines = text.split("\n")
        # Find the minimum heading level present
        min_level = 6
        for line in lines:
            match = re.match(r"^(#{1,6})\s", line)
            if match:
                level = len(match.group(1))
                min_level = min(min_level, level)

        # If headings start at H1, shift everything down by 1
        if min_level == 1:
            shifted_lines = []
            first_h1_removed = False
            for line in lines:
                match = re.match(r"^(#{1,6})\s(.+)$", line)
                if match:
                    level = len(match.group(1))
                    # Remove the first H1 (it becomes the title in YAML)
                    if level == 1 and not first_h1_removed:
                        first_h1_removed = True
                        continue
                    # Shift remaining headings: H1->H2, H2->H3, etc.
                    new_level = min(level + 1, 6)
                    shifted_lines.append(f"{'#' * new_level} {match.group(2)}")
                else:
                    shifted_lines.append(line)
            return "\n".join(shifted_lines)

        return text

    def extract_first_heading(self, text: str) -> str | None:
        """Extract the first H1 heading text from Markdown."""
        match = re.search(r"^#\s+(.+)$", text, re.MULTILINE)
        if match:
            return match.group(1).strip()
        return None

    def inject_yaml_header(
        self, text: str, chapter_config: dict, book_config: dict
    ) -> str:
        """Prepend YAML front matter to the Markdown content."""
        # Try to extract title from document if not in config
        title = chapter_config.get("title") or self.extract_first_heading(text) or "Untitled"

        # Normalize headings (shift H1 → H2, remove duplicate title)
        text = self.normalize_headings(text)

        # Build YAML front matter
        yaml_lines = [
            "---",
            f"title: \"{title}\"",
            f"chapter: {chapter_config.get('chapter', 0)}",
            f"book: \"{book_config.get('book_title', 'Unknown')}\"",
            f"author: \"{book_config.get('book_author', 'Unknown')}\"",
        ]

        topics = chapter_config.get("topics", [])
        if topics:
            yaml_lines.append("topics:")
            for topic in topics:
                yaml_lines.append(f"  - \"{topic}\"")

        key_terms = chapter_config.get("key_terms", [])
        if key_terms:
            yaml_lines.append("key_terms:")
            for term in key_terms:
                yaml_lines.append(f"  - \"{term}\"")

        yaml_lines.append(f"converted_date: \"{date.today().isoformat()}\"")
        yaml_lines.append("---")
        yaml_lines.append("")

        yaml_header = "\n".join(yaml_lines)
        return yaml_header + text


if __name__ == "__main__":
    # Quick test
    sample = """# Trial Preparation

## Getting Started

This is a test of the \\post-processor\\.

### Subsection

Multiple


blank


lines above.

Some text with {.unnumbered} artifacts.
"""
    pp = PostProcessor()
    result = pp.clean(sample)
    result = pp.normalize_headings(result)
    print(result)
